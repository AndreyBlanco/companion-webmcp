import { writeFileSync } from 'node:fs';

const sampleRate = 16_000;
const seconds = 1;
const samples = sampleRate * seconds;
const buffer = Buffer.alloc(44 + samples * 2);
buffer.write('RIFF', 0);
buffer.writeUInt32LE(buffer.length - 8, 4);
buffer.write('WAVEfmt ', 8);
buffer.writeUInt32LE(16, 16);
buffer.writeUInt16LE(1, 20);
buffer.writeUInt16LE(1, 22);
buffer.writeUInt32LE(sampleRate, 24);
buffer.writeUInt32LE(sampleRate * 2, 28);
buffer.writeUInt16LE(2, 32);
buffer.writeUInt16LE(16, 34);
buffer.write('data', 36);
buffer.writeUInt32LE(samples * 2, 40);
for (let index = 0; index < samples; index += 1) {
  const value = Math.round(Math.sin(2 * Math.PI * 440 * index / sampleRate) * 4_000);
  buffer.writeInt16LE(value, 44 + index * 2);
}
writeFileSync(new URL('access-check.wav', import.meta.url), buffer);
